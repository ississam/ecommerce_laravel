<!-- Authentication Links -->
<?php if(auth()->guard()->guest()): ?>
	

        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>

    <?php if(Route::has('register')): ?>

            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>

    <?php endif; ?>
<?php else: ?>

        <a id="navbarDropdown" class="nav-link" href="#" role="button" data-toggle="dropdown" style=" color: #FFFFFF" ><i class="fa fa-user-o" style=" color:  #FF0000"></i>
            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
        </a>


            <ul>
                <div class="dropdown-menu" style="background-color: #1E1F29" aria-labelledby="navbarDropdown">
                <li>
            <a class="dropdown-item" href="<?php echo e(route('home')); ?>">Mes commandes</a>
        </li> </br>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </li>
    </div>
    </ul>




<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ecommerce-alaravel\resources\views/partials/auth.blade.php ENDPATH**/ ?>
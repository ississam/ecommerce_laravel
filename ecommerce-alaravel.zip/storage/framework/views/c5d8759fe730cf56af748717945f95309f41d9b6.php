
<form action="<?php echo e(route('products.search')); ?>">
    <input type="text" name="q" class="input" placeholder="Search here"  value="<?php echo e(request()->q ?? ''); ?>">
    <button  type="submit" class="search-btn">Search</button>
</form>
<?php /**PATH C:\xampp\htdocs\ecommerce-alaravel\resources\views/partials/search.blade.php ENDPATH**/ ?>